const DEFAULT_SHORTCUTS = [
  { name: "YouTube", url: "https://youtube.com", icon: "▶" },
  { name: "GitHub", url: "https://github.com", icon: "⌘" },
  { name: "Gmail", url: "https://mail.google.com", icon: "✉" },
  { name: "Wikipedia", url: "https://wikipedia.org", icon: "W" }
];
const THEMES = {
  fire: { label: "Fire", accent: "#ef3340", dark: "#bd2030", bg: "#fff7f1", soft: "#fff0e7" },
  water: { label: "Water", accent: "#198bd0", dark: "#12629a", bg: "#f1f9ff", soft: "#e5f4ff" },
  grass: { label: "Grass", accent: "#4a9b55", dark: "#31723a", bg: "#f4fbf1", soft: "#e7f4e3" },
  electric: { label: "Electric", accent: "#e0a900", dark: "#9b7600", bg: "#fffbed", soft: "#fff5c9" },
  psychic: { label: "Psychic", accent: "#a44daf", dark: "#76327f", bg: "#fff5ff", soft: "#f8e7fa" }
};
const state = {
  shortcuts: DEFAULT_SHORTCUTS,
  theme: "fire",
  sounds: true,
  twentyFourHour: false,
  memo: ""
};
const webExtension = typeof browser !== "undefined"
  ? browser
  : (typeof chrome !== "undefined" ? chrome : null);
const storage = {
  get: (keys) => new Promise(resolve => {
    if (webExtension && webExtension.storage && webExtension.storage.local) {
      if (typeof browser !== "undefined") {
        webExtension.storage.local.get(keys).then(resolve);
      } else {
        webExtension.storage.local.get(keys, resolve);
      }
    } else {
      resolve(readLocalStorage());
    }
  }),
  set: (data) => new Promise(resolve => {
    if (webExtension && webExtension.storage && webExtension.storage.local) {
      if (typeof browser !== "undefined") {
        webExtension.storage.local.set(data).then(resolve);
      } else {
        webExtension.storage.local.set(data, resolve);
      }
    } else {
      localStorage.setItem("pglove", JSON.stringify(Object.assign(readLocalStorage(), data)));
      resolve();
    }
  })
};
function readLocalStorage() {
  try {
    return JSON.parse(localStorage.getItem("pglove") || "{}");
  } catch (error) {
    return {};
  }
}
let audioContext;
function beep(frequency = 520, duration = .08) {
  if (!state.sounds) return;
  if (!audioContext) {
    const AudioContextConstructor = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextConstructor) return;
    audioContext = new AudioContextConstructor();
  }
  const oscillator = audioContext.createOscillator();
  const gain = audioContext.createGain();
  oscillator.frequency.value = frequency;
  oscillator.type = "square";
  gain.gain.setValueAtTime(.025, audioContext.currentTime);
  gain.gain.exponentialRampToValueAtTime(.001, audioContext.currentTime + duration);
  oscillator.connect(gain).connect(audioContext.destination);
  oscillator.start();
  oscillator.stop(audioContext.currentTime + duration);
}
function applyTheme() {
  const theme = THEMES[state.theme] || THEMES.fire;
  document.documentElement.style.setProperty("--accent", theme.accent);
  document.documentElement.style.setProperty("--accent-dark", theme.dark);
  document.documentElement.style.setProperty("--bg", theme.bg);
  document.documentElement.style.setProperty("--surface-soft", theme.soft);
  document.documentElement.style.setProperty("--accent-rgb", hexToRgb(theme.accent));
  renderThemes();
}
function hexToRgb(hex) {
  const value = hex.replace("#", "");
  return `${parseInt(value.slice(0, 2), 16)}, ${parseInt(value.slice(2, 4), 16)}, ${parseInt(value.slice(4, 6), 16)}`;
}
function renderThemes() {
  document.querySelector("#theme-list").innerHTML = Object.entries(THEMES).map(([key, theme]) =>
    `<button class="theme-option ${state.theme === key ? "active" : ""}" data-theme="${key}" style="--theme:${theme.accent}" role="radio" aria-checked="${state.theme === key}"><span></span>${theme.label}</button>`
  ).join("");
}
function renderShortcuts() {
  document.querySelector("#shortcut-grid").innerHTML = state.shortcuts.map((shortcut, index) => {
    const safeName = escapeHtml(shortcut.name);
    const safeUrl = escapeHtml(shortcut.url);
    return `<a class="shortcut" href="${safeUrl}" data-index="${index}"><span class="shortcut-icon">${escapeHtml(shortcut.icon || shortcut.name[0].toUpperCase())}</span><span><strong class="shortcut-name">${safeName}</strong><small class="shortcut-url">${safeUrl.replace(/^https?:\/\//, "")}</small></span><button class="remove-shortcut" data-remove="${index}" type="button" aria-label="Remove ${safeName}">×</button></a>`;
  }).join("");
}
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[char])); }
function updateClock() {
  const now = new Date();
  document.querySelector("#date-line").textContent = now.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric", year: "numeric" }) + " · " + now.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit", hour12: !state.twentyFourHour });
}
async function persist(data) { Object.assign(state, data); await storage.set(data); }
async function boot() {
  Object.assign(state, await storage.get(["shortcuts", "theme", "sounds", "twentyFourHour", "memo"]));
  if (!state.shortcuts) state.shortcuts = DEFAULT_SHORTCUTS.slice();
  if (!state.theme) state.theme = "fire";
  state.sounds = state.sounds !== false;
  if (!state.memo) state.memo = "";
  applyTheme();
  renderShortcuts();
  document.querySelector("#memo").value = state.memo;
  document.querySelector("#memo-count").textContent = state.memo.length;
  document.querySelector("#sound-setting").checked = state.sounds;
  document.querySelector("#sound-toggle").textContent = state.sounds ? "♫" : "♩";
  document.querySelector("#clock-setting").checked = state.twentyFourHour;
  updateClock();
  setInterval(updateClock, 30000);
}
document.querySelector("#search-form").addEventListener("submit", event => {
  event.preventDefault();
  const input = document.querySelector("#search-input");
  const query = input.value.trim();
  if (!query) { input.focus(); return; }
  beep(680, .11);
  window.location.href = document.querySelector("#search-engine").value + encodeURIComponent(query);
});
document.querySelector("#theme-list").addEventListener("click", async event => {
  const button = event.target.closest("[data-theme]");
  if (!button) return;
  await persist({ theme: button.dataset.theme });
  applyTheme();
  beep(600, .07);
});
document.querySelector("#shortcut-grid").addEventListener("click", async event => {
  const remove = event.target.closest("[data-remove]");
  if (!remove) return;
  event.preventDefault();
  event.stopPropagation();
  state.shortcuts.splice(Number(remove.dataset.remove), 1);
  await persist({ shortcuts: state.shortcuts });
  renderShortcuts();
  beep(320, .08);
});
document.querySelector("#add-shortcut").addEventListener("click", () => {
  openShortcutDialog();
});
document.querySelector("#shortcut-form").addEventListener("submit", async event => {
  event.preventDefault();
  const name = document.querySelector("#shortcut-name").value.trim();
  let url = document.querySelector("#shortcut-url").value.trim();
  if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
  state.shortcuts.push({ name, url, icon: name[0].toUpperCase() });
  await persist({ shortcuts: state.shortcuts });
  renderShortcuts();
  closeShortcutDialog();
  event.target.reset();
  beep(760, .12);
});
document.querySelector("#memo").addEventListener("input", event => {
  document.querySelector("#memo-count").textContent = event.target.value.length;
  persist({ memo: event.target.value });
});
function toggleDrawer(open) {
  document.querySelector("#settings-drawer").classList.toggle("open", open);
  document.querySelector("#drawer-scrim").classList.toggle("open", open);
  document.querySelector("#settings-drawer").setAttribute("aria-hidden", String(!open));
}
document.querySelector("#settings-toggle").addEventListener("click", () => toggleDrawer(true));
document.querySelector("#settings-close").addEventListener("click", () => toggleDrawer(false));
document.querySelector("#drawer-scrim").addEventListener("click", () => toggleDrawer(false));
document.querySelector("#sound-toggle").addEventListener("click", async () => {
  await persist({ sounds: !state.sounds });
  document.querySelector("#sound-toggle").textContent = state.sounds ? "♫" : "♩";
  document.querySelector("#sound-setting").checked = state.sounds;
  if (state.sounds) beep(700, .1);
});
document.querySelector("#sound-setting").addEventListener("change", event => persist({ sounds: event.target.checked }).then(() => {
  state.sounds = event.target.checked;
  document.querySelector("#sound-toggle").textContent = state.sounds ? "♫" : "♩";
}));
document.querySelector("#clock-setting").addEventListener("change", event => persist({ twentyFourHour: event.target.checked }).then(updateClock));
document.querySelector("#reset-settings").addEventListener("click", async () => {
  if (!window.confirm("Reset shortcuts, theme, sounds, and memo?")) return;
  await persist({ shortcuts: DEFAULT_SHORTCUTS, theme: "fire", sounds: true, twentyFourHour: false, memo: "" });
  await boot();
  toggleDrawer(false);
});
document.addEventListener("keydown", event => {
  if (event.key === "/" && document.activeElement.tagName !== "INPUT" && document.activeElement.tagName !== "TEXTAREA") {
    event.preventDefault(); document.querySelector("#search-input").focus();
  }
  if (event.key === "Escape") {
    toggleDrawer(false);
    closeShortcutDialog();
  }
});
function openShortcutDialog() {
  const dialog = document.querySelector("#shortcut-dialog");
  if (typeof dialog.showModal === "function") {
    dialog.showModal();
  } else {
    dialog.classList.add("dialog-open");
  }
  document.querySelector("#shortcut-name").focus();
}
function closeShortcutDialog() {
  const dialog = document.querySelector("#shortcut-dialog");
  if (typeof dialog.close === "function" && dialog.open) {
    dialog.close();
  } else {
    dialog.classList.remove("dialog-open");
  }
}
boot();
