# PGlove Extension v1.0.4 — Coming Soon

PGlove is a self-contained new-tab browser extension with a playful pixel-inspired interface.

## Features

- Pokéball-inspired visual language without external assets or network dependencies.
- Search with Google, Bing, or DuckDuckGo.
- Persistent quick shortcuts with add/remove controls.
- Fire, Water, Grass, Electric, and Psychic themes.
- Optional synthesized sound effects that work offline.
- Persistent trainer memo, live date/time, and 12/24-hour clock setting.
- Keyboard shortcut: `/` focuses search.
- One shared HTML/CSS/JavaScript codebase with no external dependencies.
- Chrome, Microsoft Edge, Opera: use `manifest.json` (Manifest V3).
- Firefox: use `manifest.json` for current Firefox.
- Pale Moon and older Safari Web Extension conversion: use `manifest.v2.json`.

## Install on Chromium browsers

1. Open `chrome://extensions` or `edge://extensions`.
2. Enable **Developer mode**.
3. Select **Load unpacked**.
4. Choose `C:\Users\Aditya\PGlove`.
5. Open a new tab to use PGlove.

Opera uses `opera://extensions` with the same **Load unpacked** flow.

## Install on Firefox

Open `about:debugging` > **This Firefox** > **Load Temporary Add-on**, then select `manifest.json`.

## Pale Moon

Pale Moon uses the legacy WebExtension manifest. Make a copy of this folder, rename `manifest.v2.json` to `manifest.json`, then install that copy from Add-ons Manager. The shared `newtab.html`, `styles.css`, and `app.js` files remain unchanged.

## Safari

Safari requires an Xcode Safari Web Extension wrapper and code signing. In macOS Xcode, choose **File > New > Project > Safari Web Extension**, replace the generated web-extension files with the files in this folder, and build/sign the wrapper. Safari's extension converter does not run on Windows.

The extension intentionally uses only local files, the `storage` permission, and standard WebExtension APIs. It does not collect browsing data.
